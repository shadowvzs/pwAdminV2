fs = require('fs');
fs.readFile('./skill.txt', 'utf8', function(err, b) {
    const regEx = /\^[0-9a-f]{6}/ig;
    const text = b.replaceAll(regEx, '');

    const lines = text.split(/\n/);
    const data = [];
    let item = {};
    for (let i = 0; i < lines.length;i++) {
        const line = lines[i].trim();
        const tmp1 = parseInt(line.split('  ')[0]);
        const tmp2 = parseInt((lines[i + 1] || '').trim().split('  ')[0]);
		const tmp3 = (lines[i + 2] || '').trim();
        if (!isNaN(tmp1) && (tmp1 + 1) === tmp2) {
            if (tmp3 !== '') { 
                i = i+1;
                continue;
            }
            if (Object.keys(item).length) { data.push(item); }
            item = { 
                id: parseInt(tmp1) / 10,
                name: line.split('"')[1].trim()
            };
            i = i + 2;
        } else {
            item.description = (item.description ? item.description + "\r\n" : '') + lines[i];
        }
    }
    
    fs.writeFile('helloworld.json', JSON.stringify(data), function (err) {
      if (err) return console.log(err);
      console.log('Hello World > helloworld.txt');
    });
    console.log(data);
});
